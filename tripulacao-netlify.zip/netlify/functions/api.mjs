import { getStore } from "@netlify/blobs";

const SLOTS = {
  cap: "Capitão",
  imd: "Imediato",
  esp: "Espadachim",
  nav: "Navegador",
  ati: "Atirador",
  car: "Carpinteiro",
  med: "Médico",
};
const ONLINE_MS = 75000;

const crew = () => getStore("crew");
const people = () => getStore("people");
const presence = () => getStore("presence");
const photos = () => getStore("photos");
const audit = () => getStore("audit");

const json = (d, s = 200) =>
  Response.json(d, { status: s, headers: { "cache-control": "no-store" } });
const fail = (s, m) => json({ error: m }, s);

function rid(n) {
  const a = new Uint8Array(n);
  crypto.getRandomValues(a);
  return [...a].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function sha(t) {
  const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(t));
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function clean(s, n) {
  return String(s ?? "").replace(/[\u0000-\u001f<>]/g, "").trim().slice(0, n);
}
const okPhoto = (p) =>
  typeof p === "string" &&
  p.length <= 150000 &&
  /^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(p);
const okId = (s) => typeof s === "string" && /^[a-f0-9]{32}$/.test(s);

let stateCache = { t: 0, v: null };

async function auth(req) {
  const id = req.headers.get("x-user-id");
  const tk = req.headers.get("x-user-token");
  if (!okId(id) || !tk) return null;
  const p = await people().get(id, { type: "json" });
  if (!p || p.tokenHash !== (await sha(tk))) return null;
  return { id, p };
}

async function log(actor, entry) {
  const ts = Date.now();
  const key = String(9999999999999 - ts).padStart(13, "0") + "-" + rid(3);
  await audit().setJSON(key, { ts, actorId: actor.id, actorName: actor.p.name, ...entry });
}

async function readState() {
  if (stateCache.v && Date.now() - stateCache.t < 3000) return stateCache.v;
  const ids = Object.keys(SLOTS);
  const cards = await Promise.all(ids.map((id) => crew().get(id, { type: "json" })));
  const { blobs } = await people().list();
  const keys = blobs.map((b) => b.key).slice(0, 300);
  const rows = await Promise.all(
    keys.map(async (k) => {
      const [p, seen] = await Promise.all([
        people().get(k, { type: "json" }),
        presence().get(k, { type: "text" }),
      ]);
      return [k, p, Number(seen) || p?.createdAt || 0];
    })
  );
  const now = Date.now();
  const out = { crew: {}, people: {} };
  ids.forEach((id, i) => {
    if (cards[i]) out.crew[id] = cards[i];
  });
  for (const [k, p, seen] of rows) {
    if (!p) continue;
    out.people[k] = {
      name: p.name,
      photoV: p.photoV || 0,
      lastSeen: seen,
      online: now - seen < ONLINE_MS,
    };
  }
  stateCache = { t: now, v: out };
  return out;
}

export default async (req) => {
  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/api\/?/, "");
  const parts = path.split("/");
  const post = req.method === "POST";

  try {
    if (req.method === "GET" && path === "state") return json(await readState());

    if (req.method === "GET" && parts[0] === "photo" && parts.length === 3) {
      const kind = parts[1];
      const id = parts[2];
      if (!((kind === "p" && okId(id)) || (kind === "c" && SLOTS[id]))) return fail(404, "not found");
      const text = await photos().get(kind + "-" + id, { type: "text" });
      if (!text) return fail(404, "not found");
      const buf = Buffer.from(text.split(",")[1] || "", "base64");
      return new Response(buf, {
        headers: {
          "content-type": "image/jpeg",
          "cache-control": "public, max-age=31536000, immutable",
        },
      });
    }

    if (req.method === "GET" && path === "log") {
      const { blobs } = await audit().list();
      const keys = blobs.map((b) => b.key).sort();
      if (keys.length > 500) {
        await Promise.all(keys.slice(400).map((k) => audit().delete(k)));
      }
      const rows = await Promise.all(keys.slice(0, 80).map((k) => audit().get(k, { type: "json" })));
      return json(rows.filter(Boolean));
    }

    if (post && path === "join") {
      const b = await req.json().catch(() => ({}));
      const name = clean(b.name, 20);
      if (!name) return fail(400, "Digite um nome.");
      if (b.photo && !okPhoto(b.photo)) return fail(400, "Foto inválida.");
      const a = await auth(req);
      if (a) {
        const p = { ...a.p };
        const changes = [];
        if (name !== p.name) {
          changes.push({ field: "nome", from: p.name, to: name });
          p.name = name;
        }
        if (b.photo) {
          await photos().set("p-" + a.id, b.photo);
          p.photoV = Date.now();
          changes.push({ field: "foto" });
        }
        await people().setJSON(a.id, p);
        await presence().set(a.id, String(Date.now()));
        if (changes.length) await log({ id: a.id, p }, { kind: "profile", changes });
        stateCache = { t: 0, v: null };
        return json({ id: a.id });
      }
      const id = rid(16);
      const token = rid(24);
      const now = Date.now();
      const p = { name, tokenHash: await sha(token), photoV: 0, createdAt: now };
      if (b.photo) {
        await photos().set("p-" + id, b.photo);
        p.photoV = now;
      }
      await people().setJSON(id, p);
      await presence().set(id, String(now));
      await log({ id, p }, { kind: "join" });
      stateCache = { t: 0, v: null };
      return json({ id, token });
    }

    if (post && path === "ping") {
      const a = await auth(req);
      if (!a) return fail(401, "unauthorized");
      await presence().set(a.id, String(Date.now()));
      return json({ ok: true });
    }

    if (post && path === "card") {
      const a = await auth(req);
      if (!a) return fail(401, "unauthorized");
      const b = await req.json().catch(() => ({}));
      const slot = b.slot;
      if (!SLOTS[slot]) return fail(400, "Carta inválida.");
      const cur = (await crew().get(slot, { type: "json" })) || {};

      if (b.reset) {
        const label = cur.role || SLOTS[slot];
        await crew().delete(slot);
        await photos().delete("c-" + slot);
        stateCache = { t: 0, v: null };
        await log(a, { kind: "reset", slot, slotRole: label, changes: [] });
        return json({ ok: true });
      }

      const changes = [];
      const nameOf = async (pid) => (await people().get(pid, { type: "json" }))?.name || "Alguém";

      if (b.personId !== undefined) {
        if (b.personId === null || b.personId === "") {
          if (cur.personId) {
            changes.push({ field: "pessoa", from: await nameOf(cur.personId), to: null });
            delete cur.personId;
          }
        } else {
          if (!okId(b.personId)) return fail(400, "Pessoa inválida.");
          const target = await people().get(b.personId, { type: "json" });
          if (!target) return fail(400, "Pessoa não encontrada.");
          if (cur.personId !== b.personId) {
            changes.push({
              field: "pessoa",
              from: cur.personId ? await nameOf(cur.personId) : null,
              to: target.name,
            });
            cur.personId = b.personId;
          }
        }
      }
      if (typeof b.name === "string") {
        const n = clean(b.name, 16);
        if (n !== (cur.name || "")) {
          changes.push({ field: "nome", from: cur.name || "", to: n });
          cur.name = n;
        }
      }
      if (typeof b.role === "string") {
        const r = clean(b.role, 22) || SLOTS[slot];
        if (r !== (cur.role || SLOTS[slot])) {
          changes.push({ field: "função", from: cur.role || SLOTS[slot], to: r });
          cur.role = r;
        }
      }
      if (b.photo) {
        if (!okPhoto(b.photo)) return fail(400, "Foto inválida.");
        await photos().set("c-" + slot, b.photo);
        cur.photoV = Date.now();
        changes.push({ field: "foto" });
      }
      if (!changes.length) return json({ ok: true });
      await crew().setJSON(slot, cur);
      stateCache = { t: 0, v: null };
      await log(a, { kind: "card", slot, slotRole: cur.role || SLOTS[slot], changes });
      return json({ ok: true });
    }

    return fail(404, "not found");
  } catch (e) {
    return fail(500, "Erro no servidor.");
  }
};

export const config = { path: "/api/*" };
